package com.pixo.controller;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class IndexController {

	static Logger logger=Logger.getLogger(IndexController.class);
	
	@RequestMapping(value="/")
	public String SignUpPage()
	{
		return "Login";
	}
	
	@RequestMapping(value="LoginPage")
	public String LoginPage()
	{
		return "Login";
	}
	
	@RequestMapping(value="SignUpPage")
	public String SignUpPage2()
	{
		return "SignUp";
	}
	
	@RequestMapping(value="singlemedia")
	public String UploadSinglePage(){
		return "UploadSingle";
	}
	
	@RequestMapping(value="multiplemedia")
	public String UploadMultiplePage(){
		return "UploadMultiple";
	}
	
	
	@RequestMapping(value="followersfollowing")
	public String followersfollowingPage(){
		return "FollowersFollowing";
	}

	@RequestMapping(value="accountUpdate")
	public String accountUpdatePage(){
		return "AccountUpdate";
	}

	@RequestMapping(value="blockedAccounts")
	public String blockedAccountsPage(){
		return "BlockedAccounts";
	}
}
