package com.pixo.dao;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import com.pixo.bean.MyMedia;
import com.pixo.bean.ProfilePicture;
import com.pixo.bean.UserComments;
import com.pixo.bean.AccountDetails;

@Repository("UserDAO")
public class UserDAOImpl implements UserDAO {

	@Autowired
	@Qualifier("sessionFactory")
	SessionFactory sessionFactory;
	
	public UserDAOImpl() {
    }

	public UserDAOImpl(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }
	
	@Transactional
	public boolean registerUser(AccountDetails user) {
		
		Session session=null;
		try{
			session=sessionFactory.getCurrentSession();
			session.save(user);
		}catch(Exception e){
			e.printStackTrace();
			return false;
		}
		return true;
		
	}

	@Transactional
	public boolean authenticate(String email, String password) {
		Session session=null;
		session=sessionFactory.getCurrentSession();
		Query query=session.createQuery("from AccountDetails where EmailId=? and Password=?");
		query.setParameter(0,email);
		query.setParameter(1,password);
		AccountDetails user=(AccountDetails)query.getSingleResult();
		return true;
	}

	@Transactional
	public AccountDetails getUser(String email) {
		Session session=null;
		session=sessionFactory.getCurrentSession();
		Query query=session.createQuery("from AccountDetails where EmailId=?");
		query.setParameter(0,email);
		AccountDetails user=(AccountDetails)query.getSingleResult();
		return user;
	}

	@Transactional
	public boolean uploadProfilePicture(ProfilePicture pic) {
		sessionFactory.getCurrentSession().save(pic);
		return true;	
	}

	@Transactional
	public ProfilePicture showImage(int id) {
		Session session=null;
		session=sessionFactory.getCurrentSession();
		Query query=session.createQuery("from ProfilePicture where userId=?");
		query.setParameter(0,id);
		ProfilePicture file=(ProfilePicture)query.getSingleResult();
		return file;	
	}

	@Transactional
	public boolean uploadMedia(MyMedia myMedia) {
		sessionFactory.getCurrentSession().save(myMedia);
		return true;
	}
	
	@Transactional
	public List<MyMedia> showMedia(int id) {
		System.out.println("Here i am");
		List<MyMedia> allMedia=new ArrayList<>();
		Session session=sessionFactory.getCurrentSession();
		Query query=session.createQuery("from MyMedia where userId=?");
		query.setParameter(0,id);
		allMedia=query.getResultList();
		return allMedia;
	}

	@Transactional
	public boolean addComment(UserComments cmt) {	
			Session session=sessionFactory.getCurrentSession();
			session.persist(cmt);		
		return true;
	}

	@Transactional
	public List<UserComments> showComments(int picId) {
		
		Session session=sessionFactory.getCurrentSession();
		Query query=session.createQuery("from UserComments where picId=?");
		query.setParameter(0,picId);
		System.out.println(picId);
		List<UserComments> comments=query.getResultList();
		for(UserComments c:comments)
		{
			System.out.println(c.getComment());
		}
		return comments;
		
	}

	@Transactional
	public boolean updateUser(int id,String userName, String password, String emailID) {
		Session session=null;
		session=sessionFactory.getCurrentSession();
		System.out.println("update here");
		Query query=session.createQuery("from AccountDetails where id=?");
		query.setParameter(0,id);
		AccountDetails user=(AccountDetails)query.getSingleResult();
		System.out.println("Update here 2");
		user.setPassword(password);
		user.setName(userName);
		user.setEmailId(emailID);
		return true;
	}

}
