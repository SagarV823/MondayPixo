package com.pixo.service;

import com.pixo.bean.ProfilePicture;
import com.pixo.bean.UserComments;

import java.util.List;

import com.pixo.bean.AccountDetails;

public interface UserService {

	public boolean registerUser(AccountDetails user);
	public boolean authenticate(String email,String password);
	public AccountDetails getUser(String email);
	public boolean uploadProfilePicture(ProfilePicture pic);
	public boolean addComment(UserComments cmt);
	public List<UserComments> showComments(int picId);
	public boolean updateUser(int id,String userName,String password,String emailID);
}
